package com.example.wk02hw01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class successfulLogIn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_successful_login);
    }
}