package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.project2.DB.FlightDatabase;
import com.example.project2.DB.FlightLogDAO;
import com.example.project2.DB.ReservationDAO;
import com.example.project2.DB.ReservationDatabase;

import java.util.List;

public class ReserveSeat extends AppCompatActivity {

    private static final String M1 = "Button State";

    boolean m1 = true;

    EditText mDeparture;
    EditText mArrival;
    EditText mTicketNum;
    EditText mTicketPrice;

    Button button;

    //    ReservationDAO mReservationDAO;
    FlightLogDAO mFlightLogDAO;
    List<FlightLog> mFlightLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserve_seat);

        if(savedInstanceState != null){
            m1 = savedInstanceState.getBoolean(M1,true);
        }

        mDeparture = findViewById(R.id.departureET);
        mArrival = findViewById(R.id.arrivalET);
        mTicketNum = findViewById(R.id.numTicketsET);
        button = findViewById(R.id.flightSearchBtn);

        mFlightLogDAO = Room.databaseBuilder(this, FlightDatabase.class, FlightDatabase.dbName)
                .allowMainThreadQueries()
                .build()
                .getFlightLogDAO();

//        mReservationDAO = Room.databaseBuilder(this, ReservationDatabase.class, ReservationDatabase.dbName)
//                .allowMainThreadQueries()
//                .build()
//                .getReservationDAO();
//
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                m1 = !m1;
                checkFlights();
                addToDataBase();
            }
        });

    }


    private void addToDataBase() {
        String departure = mDeparture.getText().toString();
        String arrival = mArrival.getText().toString();

//        int numOfTickets = Integer.parseInt(mTicketNum.getText().toString());
//        int priceOfTickets = Integer.parseInt(mTicketPrice.getText().toString());

        int numOfTickets = Integer.parseInt(mTicketNum.getText().toString());
//        double priceOfTickets = Double.parseDouble(mTicketPrice.getText().toString());

        mFlightLogDAO.insert(new FlightLog(departure, arrival, numOfTickets));


//        mFlightLogDAO.insert(new FlightLog(departure, arrival, numOfTickets, priceOfTickets));

    }


    private void checkFlights(){
        Intent intent = new Intent(this, SelectFlight.class);
        startActivity(intent);
    }
}
