package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

import com.example.project2.DB.FlightDatabase;


public class ReserveSeatDisplay extends ReserveSeat {

    TextView mainDisplay;

    private static final String M1 = "Button State";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserve_seat_display);


        if(savedInstanceState != null){
            m1 = savedInstanceState.getBoolean(M1,true);
        }

//      connect display for data. Added scroll bar method
        mainDisplay = findViewById(R.id.reserveSeatDisplay);
        mainDisplay.setMovementMethod(new ScrollingMovementMethod());

        button = findViewById(R.id.checkFlightBtn);

        mFlightLogDAO = Room.databaseBuilder(this, FlightDatabase.class, FlightDatabase.dbName)
                .allowMainThreadQueries()
                .build()
                .getFlightLogDAO();
        refreshDisplay();

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                m1 = !m1;
                selectFlight();
            }
        });
    }

    private void selectFlight(){
        Intent intent = new Intent(this, MainMenu.class);
        startActivity(intent);
    }

    private void refreshDisplay() {
        mFlightLog = mFlightLogDAO.getFlights();

        if (!mFlightLog.isEmpty()) {
            StringBuilder stringBuilder = new StringBuilder();

            for (FlightLog flightlogs : mFlightLog) {
                stringBuilder.append(flightlogs.toString());
            }
            mainDisplay.setText((stringBuilder.toString()));
        } else {
            mainDisplay.setText("No flights available");
        }
    }
}
