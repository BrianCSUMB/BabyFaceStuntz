package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SelectFlight extends AppCompatActivity {

    private static final String M1 = "Button State";


    Button selectFlight201;
    Button selectFlight205;

    boolean m1 = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_flight);

        if(savedInstanceState != null){
            m1 = savedInstanceState.getBoolean(M1,true);
        }

        selectFlight201 = findViewById(R.id.otter201btn);
        selectFlight205 = findViewById(R.id.otter205btn);

        selectFlight201.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                m1 = !m1;
                openSeatDisplay();
            }
        });
    }

    public void openSeatDisplay(){
        Intent intent = new Intent(this, ReserveSeatDisplay.class);
        startActivity(intent);
    }
}
