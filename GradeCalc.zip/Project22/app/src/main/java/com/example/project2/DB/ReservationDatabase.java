package com.example.project2.DB;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;


import com.example.project2.DB.typeconverters.DateTypeConverter;
import com.example.project2.Reservation;

@Database(entities = {Reservation.class}, version = 1)
@TypeConverters(DateTypeConverter.class)

public abstract class ReservationDatabase extends RoomDatabase {

    public static final String dbName = "db-reservation";

    public static final String RESERVATION_TABLE = "reservation";

    public abstract ReservationDAO getReservationDAO();

}