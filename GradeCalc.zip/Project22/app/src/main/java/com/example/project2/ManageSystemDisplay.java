package com.example.project2;

import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.project2.DB.ReservationDatabase;

//public class ManageSystemDisplay extends AppCompatActivity {
public class ManageSystemDisplay extends CreateAcctActivity {

    TextView mainDisplay;
//    Button button;

    private static final String M1 = "Button State";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_system_display);

        if(savedInstanceState != null){
            m1 = savedInstanceState.getBoolean(M1,true);
        }

        mainDisplay = findViewById(R.id.mainReservationDisplay);
        mainDisplay.setMovementMethod(new ScrollingMovementMethod());

        button = findViewById(R.id.submitBtn);

        mReservationDAO = Room.databaseBuilder(this, ReservationDatabase.class, ReservationDatabase.dbName)
                .allowMainThreadQueries()
                .build()
                .getReservationDAO();
        refreshDisplay();


        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                m1 = !m1;
                returnToMain();
            }
        });
    }

    public void returnToMain(){
        Intent intent = new Intent(this, MainMenu.class);
        startActivity(intent);
    }

    private void refreshDisplay(){
        mReservations = mReservationDAO.getReservations();

        if (! mReservations.isEmpty()) {
            StringBuilder stringBuilder = new StringBuilder();

            for (Reservation reservations : mReservations) {
                stringBuilder.append(reservations.toString());
            }
            mainDisplay.setText((stringBuilder.toString()));
        } else {
            mainDisplay.setText("No Reservations");
        }
    }
}
