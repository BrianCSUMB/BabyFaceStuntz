package com.example.project2;

import android.icu.text.DateFormat;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.project2.DB.FlightDatabase;
import com.example.project2.DB.ReservationDatabase;


import java.text.SimpleDateFormat;
import java.util.Date;

import static java.util.Calendar.HOUR;
import static java.util.Calendar.HOUR_OF_DAY;

@Entity(tableName = FlightDatabase.FLIGHTLOG_TABLE)
//@Entity(tableName = ReservationDatabase.RESERVATION_TABLE)
//public class FlightLog extends Reservation{
public class FlightLog {

    @PrimaryKey(autoGenerate = true)
    private int mFlightLogID;

    //    private String mN
    private String mDeparture;
    private String mArrival;
    private int mNumOfTickets;
    //    private int mTicketPrice;
//    private double mNumOfTickets;
    private double mTicketPrice;

    private Date Date;


//    public FlightLog(){}

    //    public FlightLog(String departure, String arrival, int numOfTickets, double ticketPrice){
    public FlightLog(String departure, String arrival, Integer numOfTickets){

        mDeparture = departure;
        mArrival = arrival;
        mNumOfTickets = numOfTickets;
//        mTicketPrice = ticketPrice;
        Date = new Date();
    }

    public int getFlightLogID() {
        return mFlightLogID;
    }

    public void setFlightLogID(int mFlightLogID) {
        this.mFlightLogID = mFlightLogID;
    }

    public String getDeparture() {
        return mDeparture;
    }

    public void setDeparture(String mDeparture) {
        this.mDeparture = mDeparture;
    }

    public String getArrival() {
        return mArrival;
    }

    public void setArrival(String mArrival) {
        this.mArrival = mArrival;
    }

//    public double getNumOfTickets() {
//        return mNumOfTickets;
//    }
//
//    public void setNumOfTickets(double mNumOfTickets) {
//        this.mNumOfTickets = mNumOfTickets;
//    }

//    public double getTicketPrice() {
//        mTicketPrice = mNumOfTickets * 200.50;
//        return mTicketPrice;
//    }
//
//    public void setTicketPrice(double mTicketPrice) {
//        this.mTicketPrice = mTicketPrice;
//    }

    public int getNumOfTickets() {
        return mNumOfTickets;
    }

    public void setNumOfTickets(int mNumOfTickets) {
        this.mNumOfTickets = mNumOfTickets;
    }

    public double getTicketPrice() {
        final double v = mNumOfTickets * 200.50;
        mTicketPrice = v;
        return v;
    }

    public void setTicketPrice(double mTicketPrice) {
        this.mTicketPrice = mTicketPrice;
    }

    public Date getDate() {
        return Date;
    }

    public void setDate(Date mDate) {
        this.Date = mDate;
    }

    @Override
    public String toString() {
        return "Username: " + "\n"+
                "Flight number: Otter201"+ "\n"+
                "Departure: " + mDeparture + ", " + "10:00(AM)"+ "\n" +
                "Arrival: " + mArrival + "\n" +
                "NumOfTickets: " + mNumOfTickets + "\n" +
                "Reservation number: " + mFlightLogID +"\n"
                +
                "Total amount: " + "\n"+//+ mTicketPrice;
                "=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=\n";

    }
}
