package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project2.DB.ReservationDAO;
import com.example.project2.DB.ReservationDatabase;
//import com.example.project2.ErrorMsg.SecretActivity;

import java.util.List;


public class CreateAcctActivity extends AppCompatActivity {

    //    private static final String TAG =  "Create Acct screen";
    private static final String M1 = "Button State";

    TextView mainDisplay;

    private EditText mName;
    private EditText mPassword;
    private TextView mInfo;
    private Button mLogin;


    Button button;
    TextView mTextView;

    boolean m1 = true;
    boolean isLoggedIn = false;

    ReservationDAO mReservationDAO;

    List<Reservation> mReservations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_acct);

        mName = (EditText)findViewById(R.id.Name);
        mPassword = (EditText)findViewById(R.id.Password);
        mInfo = (TextView)findViewById(R.id.mainDisplay);
        mLogin = (Button)findViewById(R.id.Login);

        if(savedInstanceState != null){
            m1 = savedInstanceState.getBoolean(M1,true);
        }

        button = findViewById(R.id.Login);
        mTextView = findViewById(R.id.mainDisplay);

        mReservationDAO = Room.databaseBuilder(this, ReservationDatabase.class, ReservationDatabase.dbName)
                .allowMainThreadQueries()
                .build()
                .getReservationDAO();
//        refreshDisplay();


        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                m1 = !m1;
                validate(mName.getText().toString(),mPassword.getText().toString());
            }
        });
    }

//    Set number of attempts to 2 so it returns user to main menu after multiple failed attempts
//    int numberOfAttempts = 2;

    public void validate(String userName, String userPassword){

        if ((userName.equals("CS28Go")) && (userPassword.equals("CS28Go")) && (isLoggedIn = true)) {

            String message = "Account created successfully";
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            //Uncomment to save acct log in
            addToDataBase();

            isLoggedIn = true;
            Intent intent = new Intent(this, MainMenu.class);
            startActivity(intent);

        } else {
            isLoggedIn = false;
//           numberOfAttempts--;
            String message = "Incorrect username or password";
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();

            openDialog();
        }
    }


    //    method to open error message
    public void openDialog(){
        AcctErrorMsg errorMsg = new AcctErrorMsg();
        errorMsg.show(getSupportFragmentManager(), "We just got fragged");
    }

    public void validateUser(){

    }

    private void addToDataBase(){
        String usernameData = mName.getText().toString();
        String passwordData = mPassword.getText().toString();

//        isLoggedIn=false;
        mReservationDAO.insert(new Reservation(usernameData, passwordData));
    }

//    private void refreshDisplay(){
//        mReservations = mReservationDAO.getReservations();
//
//        if (! mReservations.isEmpty()) {
//            StringBuilder stringBuilder = new StringBuilder();
//
//            for (Reservation reservations : mReservations) {
//                stringBuilder.append(reservations.toString());
//            }
//            mainDisplay.setText((stringBuilder.toString()));
//        } else {
//            mainDisplay.setText("Welcome To AirlineX");
//        }
//    }

}
