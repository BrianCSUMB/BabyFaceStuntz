package com.example.project2.DB;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.project2.DB.typeconverters.DateTypeConverter;
import com.example.project2.FlightLog;

@Database(entities =  {FlightLog.class}, version =  2)
@TypeConverters(DateTypeConverter.class)

public abstract class FlightDatabase extends RoomDatabase {

    public static final String dbName = "db-flightlog";

    public static final String FLIGHTLOG_TABLE = "flightlog";

    public abstract FlightLogDAO getFlightLogDAO();
}
