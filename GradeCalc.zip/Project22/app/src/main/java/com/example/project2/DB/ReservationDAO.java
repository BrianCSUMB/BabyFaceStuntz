package com.example.project2.DB;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.project2.Reservation;

import java.util.List;

@Dao
public interface ReservationDAO{
    @Insert
    void insert(Reservation... reservations);

    @Update
    void update(Reservation... reservations);

    @Delete
    void delete(Reservation... reservations);

    @Query("SELECT * FROM " + ReservationDatabase.RESERVATION_TABLE + " ORDER BY mDate DESC") //DESC
    List<Reservation> getReservations();

    @Query("SELECT * FROM " + ReservationDatabase.RESERVATION_TABLE + " WHERE mReservationId = :reservationID")
    Reservation getQuestionWithId(int reservationID);
}