package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainMenu extends AppCompatActivity {

    Button createAcct;
    Button reserveSeat;
    Button cancelRes;
    Button manageSystem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        createAcct = findViewById(R.id.btnCreateAccount);
        reserveSeat = findViewById(R.id.btnReserveSeat);
        cancelRes = findViewById(R.id.btnCancelRes);
        manageSystem = findViewById(R.id.btnManageSystem);

        createAcct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCreateAcctActivity();
            }
        });

        reserveSeat.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
//                addToDataBase();
//                refreshDisplay();
                openReserveSeatActivity();
            }
        });
//
//        cancelResBtn.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//                addToDataBase();
//                refreshDisplay();
//                openCancelReservationActivity();
//            }
//        });
//
        manageSystem.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
//                addToDataBase();
//                refreshDisplay();
                openManageSystem();
            }
        });

    }

    public void openCreateAcctActivity(){

        Intent intent = new Intent(this, CreateAcctActivity.class);
        startActivity(intent);
    }

    public void openReserveSeatActivity(){

        Intent startNewActivity = new Intent(this, ReserveSeat.class);
        startActivity(startNewActivity);
    }
    //
//    public void openCancelReservationActivity(){
//
//        Intent startNewActivity = new Intent(this, CancelReservationActivity.class);
//        startActivity(startNewActivity);
//    }
//
    public void openManageSystem(){

        Intent startNewActivity = new Intent(this, ManageSystem.class);
        startActivity(startNewActivity);
    }
}
