package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ManageSystem extends AppCompatActivity {

    private static final String M1 = "Button State";

    private EditText mName;
    private EditText mPassword;
    private TextView mInfo;
    private Button mLogin;


    Button button;
    TextView mTextView;
    boolean m1 = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_acct);

        mName = (EditText)findViewById(R.id.Name);
        mPassword = (EditText)findViewById(R.id.Password);
        mInfo = (TextView)findViewById(R.id.mainDisplay);
        mLogin = (Button)findViewById(R.id.msLogin);

        if(savedInstanceState != null){
            m1 = savedInstanceState.getBoolean(M1,true);
        }

        button = findViewById(R.id.Login);
        mTextView = findViewById(R.id.mainDisplay);

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                m1 = !m1;
                validate(mName.getText().toString(),mPassword.getText().toString());
            }
        });
    }

    private void validate(String userName, String userPassword){

        if((userName.equals("admin2")) && (userPassword.equals("admin2"))){

            String message = "Login successfull";
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();

//            Intent intent = new Intent(this, MainActivity.class);
//            startActivity(intent);
            Intent intent = new Intent(this, ManageSystemDisplay.class);
            startActivity(intent);

        }else {
            String message = "Incorrect username or password";
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();

        }
    }
}
