package com.example.project2;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.project2.DB.ReservationDatabase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Entity(tableName = ReservationDatabase.RESERVATION_TABLE)

public class Reservation {

    @PrimaryKey(autoGenerate = true)
    private int mReservationId;

    private String mName;
    private String mPassword;

    private Date mDate;


    public Reservation(){}

    public Reservation(String userName, String password){

        mName = userName;
        mPassword = password;

        mDate = new Date();
    }

    public int getReservationId() {
        return mReservationId;
    }

    public void setReservationId(int mReservationId) {
        this.mReservationId = mReservationId;
    }

    public String getName() {
        return mName;
    }

    public void setName(String mName) { this.mName = mName; }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String mPassword) {
        this.mPassword = mPassword;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date mDate) {
        this.mDate = mDate;
    }

    @Override
    public String toString() {
        return "Transaction Type : New account"+"\n"+
                "Username: "+ mName + "\n" +
                "Transaction date: "+ (new SimpleDateFormat("MM-dd-yyyy").format(mDate)) +"\n"+
                "Transaction time: "+(new SimpleDateFormat("hh:mm").format(mDate))+ "\n"+
//                mReservationId + "\n" +
                "=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=\n";
    }
}
