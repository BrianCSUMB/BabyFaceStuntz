package com.example.project2.DB;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.project2.DB.FlightDatabase;
import com.example.project2.FlightLog;

import java.util.List;

@Dao
public interface FlightLogDAO {
    @Insert
    void insert(FlightLog... flightlogs);

    @Update
    void update(FlightLog... flightlogs);

    @Delete
    void delete(FlightLog... flightlogs);

    @Query("SELECT * FROM " + FlightDatabase.FLIGHTLOG_TABLE + " ORDER BY Date DESC")
    List<FlightLog> getFlights();

    @Query("SELECT * FROM " + FlightDatabase.FLIGHTLOG_TABLE + " WHERE mFlightLogId = :flightLogID")
    FlightLog getQuestionWithId(int flightLogID);
}