package com.example.graderecorder.DB;

import androidx.room.RoomDatabase;

public abstract class CourseDatabase extends RoomDatabase {
}
