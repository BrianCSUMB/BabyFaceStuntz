package com.example.graderecorder.DB;

import androidx.room.Dao;

@Dao
public interface CousreIDDAO {
}
