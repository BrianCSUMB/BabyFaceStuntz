package com.example.gymlog.DB;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverter;
import androidx.room.TypeConverters;

import com.example.gymlog.DB.GymLogDAO;
import com.example.gymlog.DB.typeconverters.DateTypeConverter;
import com.example.gymlog.GymLog;

@Database(entities = {GymLog.class}, version = 1)
@TypeConverters(DateTypeConverter.class)
public abstract class AppDatabase extends RoomDatabase {

    public static final String dbName = "db-gymlog";

    public static final String GYMLOG_TABLE = "gymlog";

    public abstract GymLogDAO getGymLogDAO();
}
