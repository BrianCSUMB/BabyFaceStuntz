package com.example.gymlog;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.gymlog.DB.AppDatabase;

import java.util.Date;

@Entity(tableName = AppDatabase.GYMLOG_TABLE)
public class GymLog {

    @PrimaryKey(autoGenerate = true)
    private int mLogId;


    private String mExercise;

    private int mWeight;
    private int mReps;

    private Date mDate;

    public GymLog(String exercise, int weight, int reps) {
        mExercise = exercise;
        mWeight = weight;
        mReps = reps;
        mDate = new Date();
    }

    public int getLogId() {
        return mLogId;
    }

    public void setLogId(int mLogId) {
        this.mLogId = mLogId;
    }

    public String getExercise() {
        return mExercise;
    }

    public void setExercise(String mExercise) {
        this.mExercise = mExercise;
    }

    public int getWeight() {
        return mWeight;
    }

    public void setWeight(int mWeight) {
        this.mWeight = mWeight;
    }

    public int getReps() {
        return mReps;
    }

    public void setReps(int mReps) {
        this.mReps = mReps;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date mDate) {
        this.mDate = mDate;
    }

    @Override
    public String toString() {
        return mDate + "\n" +
                mExercise + "\n" +
                mWeight + "\n"+
                mReps + "\n" +
                        "=-=-=-=-=-=-\n";
    }
}
