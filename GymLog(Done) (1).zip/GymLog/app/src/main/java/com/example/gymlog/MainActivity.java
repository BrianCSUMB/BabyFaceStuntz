package com.example.gymlog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.gymlog.DB.AppDatabase;
import com.example.gymlog.DB.GymLogDAO;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView mainDisplay;

    EditText exercise;
    EditText weight;
    EditText reps;

    Button submit;

    GymLogDAO mGymLogDAO;

    List<GymLog> mGymLogs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainDisplay = findViewById(R.id.mainGymLogDisplay);
        mainDisplay.setMovementMethod(new ScrollingMovementMethod());

        exercise = findViewById(R.id.mainExerciseEditText);
        weight = findViewById(R.id.mainWeightEditText);
        reps = findViewById(R.id.mainRepsEditText);

        submit = findViewById(R.id.mainSubmitButton);

        mGymLogDAO = Room.databaseBuilder(this, AppDatabase.class, AppDatabase.dbName)
                .allowMainThreadQueries()
                .build()
                .getGymLogDAO();
        refreshDisplay();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToDataBase();
                refreshDisplay();
            }
        });
    }

    private void addToDataBase(){
        String exerciseString = exercise.getText().toString();
        int weightInt = Integer.parseInt(weight.getText().toString());
        int repsInt = Integer.parseInt(reps.getText().toString());

        //GymLog log = new GymLog(exerciseString, weightInt, repsInt);

        mGymLogDAO.insert(new GymLog(exerciseString, weightInt, repsInt));

    }

    private void refreshDisplay(){
        mGymLogs = mGymLogDAO.getAllGymLogs();

        if(! mGymLogs.isEmpty()){
            StringBuilder stringBuilder = new StringBuilder();

            for(GymLog gymLog : mGymLogs){
                stringBuilder.append(gymLog.toString());
            }
            mainDisplay.setText((stringBuilder.toString()));
        }else{
            mainDisplay.setText("GO TO THE GYM ALREADY!!");
        }
    }
}
